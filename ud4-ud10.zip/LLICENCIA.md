# Llicència

Material desenvolupat per **David Arso Civil** per al Departament de Matemàtiques de l'INS Miquel Tarradell.

## Per què BY-NC-ND i no BY-NC-SA

La majoria de projectes de Step Quiz fan servir CC BY-NC-SA 4.0 per al contingut. Aquest, com `pau`, fa servir **CC BY-NC-ND 4.0**: és una decisió de l'autor. El material es pot fer servir i compartir tal com és, però no se'n poden difondre versions modificades.

## Què es pot fer amb aquest material

| | Contingut pedagògic | Codi |
|---|---|---|
| **Llicència** | CC BY-NC-ND 4.0 | MIT |
| Fer-lo servir a classe | Sí | Sí |
| Modificar-lo i adaptar-lo | Només per a ús propi, sense difondre'l | Sí |
| Publicar-ne la versió modificada | No | Sí |
| Ús comercial | No | Sí |
| Cal citar l'autoria | Sí | Sí |

**Contingut pedagògic** vol dir textos, exercicis, enunciats, solucions, imatges, fitxes i PDF. **Codi** vol dir els fitxers `.js`, `.py`, `.css`, les plantilles HTML i les eines de construcció.

## Què vol dir a la pràctica

L'INS Miquel Tarradell, i qualsevol altre centre, pot fer servir i compartir aquest material de manera indefinida, sense demanar permís i sense dependre de la disponibilitat de l'autor, sempre que en citi l'autoria, no en faci un ús comercial i no el modifiqui.

L'autoria correspon a la persona que va crear el material i no es transfereix: els drets morals d'autoria són irrenunciables i intransmissibles (article 14 del text refós de la Llei de propietat intel·lectual).

## Com citar-lo

> Material desenvolupat per David Arso Civil per al Departament de Matemàtiques de l'INS Miquel Tarradell.
> Contingut sota CC BY-NC-ND 4.0, codi sota llicència MIT.

El text legal complet és al fitxer [`LICENSE`](LICENSE).

## Material de tercers

Aquest projecte incorpora enunciats, figures i pàgines del llibre de text i del seu solucionari (Matemàtiques de 4t d’ESO: Santillana, «Matemáticas 4 ESO Opción A»), que no són obra de David Arso Civil.

La llicència empara únicament les aportacions pròpies: la programació, la selecció i l'organització del material, les explicacions, les pistes, les errades detectades i el disseny de l'activitat.

Aquest material conserva els drets dels seus autors i no es llicencia aquí.
